#include "Romb.h"

Romb::Romb(double a, double h) : a(a), h(h) {
	std::cout << "Konstruktor Rombu(" << a << ", " << h << ")\n";
	liczbaRombow++;
	std::cout << "Liczba figur: " << liczbaObiektow << ", Liczba rombow: " << liczbaRombow << '\n';
}

double Romb::GetA() const {
	return a;
}

double Romb::GetH() const {
	return h;
}

void Romb::SetA(double a) {
	this->a = a;
}

void Romb::SetH(double h) {
	this->h = h;
}

double Romb::Obwod() {
	return 4*a;
}

double Romb::Pole() {
	return a * h;
}

void Romb::Wypisz(std::ostream& out) const {
	out << "Romb(" << a << ", " << h << ")\n";
}

Romb::~Romb() {
	std::cout << "Dekonstruktor Rombu(" << a << ", " << h << ")\n";
}

int Romb::liczbaRombow = 0;
