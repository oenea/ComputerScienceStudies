#include "Elipsa.h"
#include <math.h>

Elipsa::Elipsa(double a, double b) : a(a), b(b) {
	std::cout << "Konstruktor Elipsy(" << a << ", " << b << ")\n";
	liczbaElips++;
	std::cout << "Liczba figur: " << liczbaObiektow << ", Liczba elips: " << liczbaElips << '\n';
}

double Elipsa::GetA() const {
	return a;
}

double Elipsa::GetB() const {
	return b;
}

void Elipsa::SetA(double a) {
	this->a = a;
}

void Elipsa::SetB(double b) {
	this->b = b;
}

double Elipsa::Obwod() {
	return M_PI*(3*((a+b)/2)-sqrt(a*b));
}

double Elipsa::Pole() {
	return M_PI * a * b;
}

void Elipsa::Wypisz(std::ostream& out) const {
	out << "Elipsa(" << a << ", " << b << ")\n";
}

Elipsa::~Elipsa() {
	std::cout << "Dekonstruktor Elipsy(" << a << ", " << b << ")\n";
}

int Elipsa::liczbaElips = 0;
