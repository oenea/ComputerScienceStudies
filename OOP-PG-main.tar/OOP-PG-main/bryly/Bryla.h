#ifndef __BRYLA_H__
#define __BRYLA_H__

#include <iostream>

class Bryla 
{
protected:
    virtual void Wypisz(std::ostream& out) const = 0;
    friend std::ostream& operator<<(std::ostream& os, const Bryla bryla);
    static int liczbaBryl;

public:
    Bryla();
    virtual ~Bryla();
    virtual double Pole() = 0;
    virtual double Obwod() = 0;
};


#endif /* __BRYLA_H__ */
