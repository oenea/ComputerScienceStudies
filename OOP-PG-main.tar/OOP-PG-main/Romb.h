#ifndef __ROMB_H__
#define __ROMB_H__

#include "FiguraPlaska.h"


class Romb : public FiguraPlaska
{
private:
	static int liczbaRombow;
	double a, h;

protected:
	void Wypisz(std::ostream& out) const override;

public:
	Romb(double a, double h);
	~Romb() override;

	double GetA() const;
	double GetH() const;

	void SetA(double a);
	void SetH(double h);

	double Obwod() override;
	double Pole() override;
};

#endif /* __ROMB_H__ */
