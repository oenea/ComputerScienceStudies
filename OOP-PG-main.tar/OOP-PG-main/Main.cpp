#include <iostream>
#include "FiguraPlaska.h"
#include "Elipsa.h"
#include "Romb.h"
#include "Prostokat.h"

void zadanie3()
{
    auto prostokat = Prostokat(2, 3);
    auto elipsa = Elipsa(1, 2);
    auto romb = Romb(3, 2);

    FiguraPlaska* arr[] = {
        &prostokat,
        &elipsa,
        &romb,
    };

    for (size_t i = 0; i < sizeof(arr) / sizeof(FiguraPlaska*); i++)
    {
        std::cout << *arr[i];
        std::cout << "Obwod: " << arr[i]->Obwod() << '\n';
        std::cout << "Pole: " << arr[i]->Pole() << '\n';
    }
}
int main()
{
    //Prostokat prostokat1 = Prostokat(9, 2);
    //Romb romb1 = Romb(10, 5);
    //Elipsa elipsa1 = Elipsa(10, 5);
    std::cout << '\n';
    zadanie3();
    std::cout << '\n';
}
