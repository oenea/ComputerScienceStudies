#ifndef __ELIPSA_H__
#define __ELIPSA_H__

#include "FiguraPlaska.h"


class Elipsa : public FiguraPlaska
{
private:
	static int liczbaElips;
	double a, b;

protected:
	void Wypisz(std::ostream& out) const override;

public:
	Elipsa(double a, double b);
	~Elipsa() override;

	double GetA() const;
	double GetB() const;

	void SetA(double a);
	void SetB(double b);

	double Obwod() override;
	double Pole() override;
};

#endif /* __ELIPSA_H__ */
